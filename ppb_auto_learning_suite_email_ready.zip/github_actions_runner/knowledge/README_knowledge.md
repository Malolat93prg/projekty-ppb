# Folder wiedzy
Dodawaj tu notatki `.md`/`.txt`. Pierwsza linia każdego pliku trafi do raportu jako nagłówek.
