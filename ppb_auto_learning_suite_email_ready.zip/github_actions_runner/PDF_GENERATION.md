# Optional PDF generation notes
# Requires: weasyprint
# Install: pip install weasyprint
# Example usage in your generator:
#   from weasyprint import HTML
#   HTML(string=markdown_html).write_pdf("reports/latest_report.pdf")