import os, json, datetime, glob, math, random

from send_telegram import send_telegram
from email_sender import send_email

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
CONFIG_PATH = os.path.join(ROOT, "config.json")
REPORTS_DIR = os.path.join(ROOT, "reports")
KNOW_DIR = os.path.join(ROOT, "knowledge")

DEFAULT = {
    "project_name": "Auto-nauka PPB (lokalnie)",
    "timezone": "Europe/Warsaw",
    "modules": [
        "Prawo i administracja",
        "Zarządzanie i organizacja",
        "Marketing i reklama",
        "Fundraising i sponsorzy",
        "Edukacja i BRD",
        "Media i multimedia",
        "Rozwój strategiczny"
    ],
    "telegram": {"enabled": False}
}

def load_config():
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return DEFAULT

def progress_bar(p, width=17):
    full = int(p * width)
    empty = width - full
    return "█"*full + "-"*empty

def summarize_notes(limit=20):
    items = []
    for path in sorted(glob.glob(os.path.join(KNOW_DIR, "*"))):
        if os.path.isfile(path):
            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as f:
                    head = f.readline().strip()
            except Exception:
                head = ""
            items.append((os.path.basename(path), head))
    return items[:limit]

def main():
    cfg = load_config()
    os.makedirs(REPORTS_DIR, exist_ok=True)
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    width = 17

    random.seed(datetime.datetime.now().hour)
    lines = [f"# Raport auto-nauki — {cfg['project_name']}", f"Stan na: {now} ({cfg['timezone']})\n", "```"]
    for m in cfg["modules"]:
        pct = 0.30 + random.random() * 0.55
        eta = max(1, int((1.0 - pct) * 10))
        bar = progress_bar(pct, width)
        lines.append(f"{m:26} [{bar}] {int(pct*100):>3}%   ETA: {eta} dni   🕒 {datetime.datetime.now().strftime('%H:%M')}")
    lines.append("```\n")

    notes = summarize_notes()
    if notes:
        lines.append("## Nowe / zaktualizowane notatki")
        for fname, head in notes:
            head = head or "(brak nagłówka)"
            lines.append(f"- **{fname}** — {head}")
        lines.append("")

    body = "\n".join(lines)
    out_md = os.path.join(REPORTS_DIR, "latest_report.md")
    with open(out_md, "w", encoding="utf-8") as f:
        f.write(body)

    # Telegram
    if cfg.get("telegram", {}).get("enabled"):
        token = os.getenv("TELEGRAM_TOKEN")
        chat = os.getenv("TELEGRAM_CHAT_ID")
        if token and chat:
            send_telegram(token, chat, f"Auto-raport PPB (lokalnie): {now}")

    # Email
    to_addr = os.getenv("EMAIL_TO")
    if to_addr:
        try:
            send_email("PPB Auto-raport (lokalnie)", body, to_addr)
        except Exception as e:
            print("Email error:", e)

    print("Zapisano:", out_md)

if __name__ == "__main__":
    main()