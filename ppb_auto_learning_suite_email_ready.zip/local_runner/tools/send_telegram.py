import os, requests

def send_telegram(token: str, chat_id: str, text: str):
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    try:
        resp = requests.get(url, params={"chat_id": chat_id, "text": text}, timeout=10)
        resp.raise_for_status()
        print("Wysłano Telegram.")
    except Exception as e:
        print("Telegram error:", e)