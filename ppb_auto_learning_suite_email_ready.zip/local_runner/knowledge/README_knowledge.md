# Dodawaj tu notatki .md/.txt — pierwsza linia pojawi się w raporcie.
