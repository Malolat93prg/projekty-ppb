# Automatyczne uruchamianie (lokalnie)
- Windows: Harmonogram zadań (co 15 min) — program: python.exe, argument: tools\generate_report.py
- macOS/Linux: cron — `*/15 * * * * /usr/bin/python3 /ścieżka/local_runner/tools/generate_report.py`

Zmienne środowiskowe (opcjonalnie):
- SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM, EMAIL_TO
- TELEGRAM_TOKEN, TELEGRAM_CHAT_ID