# Local Runner (PPB) — auto-raport nauki lokalnie

Uruchamiaj `tools/generate_report.py` ręcznie lub przez Harmonogram/cron.
Raport trafi do `reports/latest_report.md`. Opcjonalnie wyślij Telegram/e-mail.

Instrukcje planowania zadań znajdziesz w `../local_runner/schedule_instructions.md`.