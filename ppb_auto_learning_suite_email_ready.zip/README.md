# PPB Auto-Learning Suite (praktyczny gotowiec)

Dostajesz **dwa tryby pracy**:
1) `local_runner/` — działa na Twoim komputerze (Harmonogram/cron), generuje raporty i (opcjonalnie) wysyła Telegram/e-mail.
2) `github_actions_runner/` — działa w chmurze GitHub co godzinę (CRON), tworzy raport i (opcjonalnie) wysyła Telegram.

## Który tryb wybrać?
- **Chcę, żeby działało zawsze, nawet gdy komputer jest wyłączony** → użyj `github_actions_runner/`.
- **Chcę mieć wszystko lokalnie, bez chmury** → użyj `local_runner/`.

## Powiadomienia
- Telegram: włącz w `config.json` (`enabled: true`) i ustaw sekrety/env.
- E-mail: uzupełnij `.env` danymi SMTP i użyj `tools/email_sender.py`.

## PDF raportu (opcjonalnie)
- Zainstaluj `weasyprint` i skorzystaj z `PDF_GENERATION.md` — raport Markdown możesz równolegle zapisać jako PDF.

## Jak przekazać raport do dalszej nauki
- Wklej treść `reports/latest_report.md` w rozmowie lub wyślij plik — rozszerzę wiedzę i dodam kolejne moduły automatycznie.

## Bezpieczeństwo
- Tokeny trzymaj w Secrets (GitHub) albo w `.env` lokalnie (nie commituj).
- Nie przechowuj haseł w repozytorium.

Powodzenia! Masz kompletne narzędzia, aby „ciągła nauka” działała praktycznie i bez przerw.

---
## Integracja z repozytorium
- Utwórz repo na GitHub i wgraj katalog `github_actions_runner/` (zawartość) do jego głównego poziomu.
- W `Settings → Secrets and variables → Actions` dodaj sekrety SMTP i (opcjonalnie) Telegram.
- Sekrety wymagane do e-mail:
  - `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM` (opcjonalnie)
  - `EMAIL_TO` (adres odbiorcy raportów)
- Po pushu wejdź w **Actions** i uruchom workflow ręcznie lub poczekaj na CRON.
